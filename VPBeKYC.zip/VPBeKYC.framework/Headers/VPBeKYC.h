//
//  VPBeKYC.h
//  VPBeKYC
//
//  Created by Kent Vu on 10/1/20.
//  Copyright © 2020 VPBank. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for VPBeKYC.
FOUNDATION_EXPORT double VPBeKYCVersionNumber;

//! Project version string for VPBeKYC.
FOUNDATION_EXPORT const unsigned char VPBeKYCVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <VPBeKYC/PublicHeader.h>
